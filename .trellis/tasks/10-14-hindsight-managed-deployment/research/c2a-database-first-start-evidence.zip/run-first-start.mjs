import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { STAGE, TOKEN, DOCKER, ENDPOINT, docker, assertFact } from './command-runner.mjs';

const base = 'sha256:ba5161f9e70f2811c17a90e40921b17240ae275d51a7a4001fcb75fcb61c10db';
const engine = '93e8319e-24b7-4a7d-88f1-60923ad681e0';
const name = 'taki-c2a-db-first-' + TOKEN;
const volume = name + '-data';
const root = '/home/hindsight/.pg0';
const save = (leaf, value) => writeFileSync(STAGE + '/' + leaf, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const report = { version: 1, scope: 'offline-first-start-prerequisite', token: TOKEN, name, volume, base, endpoint: ENDPOINT, startedAt: new Date().toISOString(), executionPassed: false, deploymentReady: false };
const format = '{"id":{{json .Id}},"name":{{json .Name}},"image":{{json .Image}},"labels":{{json .Config.Labels}},"user":{{json .Config.User}},"entrypoint":{{json .Config.Entrypoint}},"args":{{json .Args}},"tty":{{json .Config.Tty}},"openStdin":{{json .Config.OpenStdin}},"readOnly":{{json .HostConfig.ReadonlyRootfs}},"network":{{json .HostConfig.NetworkMode}},"memory":{{json .HostConfig.Memory}},"cpus":{{json .HostConfig.NanoCpus}},"pids":{{json .HostConfig.PidsLimit}},"caps":{{json .HostConfig.CapDrop}},"security":{{json .HostConfig.SecurityOpt}},"log":{{json .HostConfig.LogConfig}},"restart":{{json .HostConfig.RestartPolicy}},"ports":{{json .HostConfig.PortBindings}},"binds":{{json .HostConfig.Binds}},"mounts":{{json .Mounts}},"state":{{json .State}}}';
const originalFormat = '{"id":{{json .Id}},"name":{{json .Name}},"status":{{json .State.Status}},"startedAt":{{json .State.StartedAt}},"restartPolicy":{{json .HostConfig.RestartPolicy.Name}}}';
let cid;
let volumeCreated = false;
let cleanupDeadline;
let original;
const cleanupOptions = (max = 15000) => {
  const remaining = cleanupDeadline - performance.now();
  assertFact(remaining > 0, 'CLEANUP_DEADLINE');
  return { cleanup: true, timeout: Math.min(max, remaining) };
};
const absent = async (kind, id, options = {}) => {
  const result = await docker([kind, 'inspect', '--format', kind === 'volume' ? '{{.Name}}' : '{{.Id}}', id], { ...options, allowFailure: true });
  assertFact(result.exitCode !== 0 && !result.failure && /No such (object|container|volume)/i.test(result.stderr), 'EXPECTED_ABSENT:' + kind);
};
async function inspectContainer(options = {}) {
  return JSON.parse((await docker(['container', 'inspect', '--format', format, cid], options)).stdout);
}
function ownedContainer(value) {
  assertFact(value.id === cid && value.name === '/' + name && value.image === base
    && value.labels?.['taki.c2a.db-first'] === TOKEN && value.labels?.['taki.c2a.role'] === 'database-first-start'
    && value.mounts.length === 1 && value.mounts[0].Type === 'volume' && value.mounts[0].Name === volume
    && value.mounts[0].Destination === root && value.mounts[0].RW === true, 'OWNED_CONTAINER');
}
async function inspectVolume(options = {}) {
  const value = JSON.parse((await docker(['volume', 'inspect', '--format', '{"name":{{json .Name}},"driver":{{json .Driver}},"labels":{{json .Labels}}}', volume], options)).stdout);
  assertFact(value.name === volume && value.driver === 'local' && value.labels?.['taki.c2a.db-first'] === TOKEN, 'OWNED_VOLUME');
  return value;
}

writeFileSync(STAGE + '/run.started', new Date().toISOString(), { flag: 'wx' });
try {
  assertFact(hash(readFileSync(DOCKER)) === '0a4d8fe2ab107ceae44ee5f5fc1e1c155790042b7e3d3163826660da882b389d', 'DOCKER_PIN');
  assertFact(hash(readFileSync('C:/Program Files/nodejs/node.exe')) === '9a4eb5f1c29c6a2e93852ead46b999e284a6a5ca8bab4d4e241d587d025a52de', 'NODE_PIN');
  const inputs = JSON.parse(readFileSync(STAGE + '/input-manifest.json', 'utf8'));
  for (const input of inputs.files) assertFact(hash(readFileSync(input.path)) === input.sha256, 'REVIEWED_INPUT_DRIFT');
  const script = readFileSync(STAGE + '/reviewed-inputs/first-start.py');
  assertFact(hash(script) === '7d1ee67f7b3027da781795e365b58a9cb93f847cdba7cc31425f05030d2f7ff6', 'SUPERVISOR_PIN');
  report.inputHashes = inputs.files;
  const info = JSON.parse((await docker(['info', '--format', '{"id":{{json .ID}},"os":{{json .OSType}},"architecture":{{json .Architecture}},"version":{{json .ServerVersion}}}'])).stdout);
  assertFact(info.id === engine && info.os === 'linux' && info.architecture === 'x86_64', 'ENGINE_PIN');
  const image = JSON.parse((await docker(['image', 'inspect', '--format', '{"id":{{json .Id}},"os":{{json .Os}},"architecture":{{json .Architecture}},"volumes":{{json (index .Config "Volumes")}}}', base])).stdout);
  assertFact(image.id === base && image.os === 'linux' && image.architecture === 'amd64' && Object.keys(image.volumes ?? {}).length === 0, 'BASE_PIN');
  save('runtime-prerequisites.json', { info, image, supervisorSha256: hash(script) });
  await absent('container', name);
  await absent('volume', volume);
  const ids = (await docker(['ps', '--all', '--quiet', '--no-trunc'])).stdout.trim().split(/\r?\n/).filter(Boolean);
  original = ids.length ? (await docker(['container', 'inspect', '--format', originalFormat, ...ids])).stdout.trim().split(/\r?\n/).map(JSON.parse) : [];
  save('original-before-containers.json', original);
  const volumeResult = await docker(['volume', 'create', '--driver', 'local', '--label', 'taki.c2a.db-first=' + TOKEN, volume]);
  assertFact(volumeResult.stdout.trim() === volume, 'CREATED_VOLUME');
  volumeCreated = true;
  report.volumeBefore = await inspectVolume();
  const created = await docker(['create', '--name', name, '--label', 'taki.c2a.db-first=' + TOKEN, '--label', 'taki.c2a.role=database-first-start',
    '--pull', 'never', '--network', 'none', '--read-only', '--user', '1000:1000', '--interactive', '--log-driver', 'none',
    '--memory', '512m', '--cpus', '1', '--pids-limit', '64', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true',
    '--mount', 'type=volume,source=' + volume + ',target=' + root, '--entrypoint', '/app/api/.venv/bin/python', base, '-I', '-B', '-']);
  cid = created.stdout.trim();
  assertFact(/^[0-9a-f]{64}$/.test(cid), 'CREATED_CID');
  report.containerId = cid;
  save('resource-identities.json', { token: TOKEN, name, volume, containerId: cid, imageId: base });
  const before = await inspectContainer();
  ownedContainer(before);
  assertFact(before.user === '1000:1000' && before.readOnly && before.network === 'none' && !before.tty && before.openStdin
    && JSON.stringify(before.entrypoint) === JSON.stringify(['/app/api/.venv/bin/python']) && JSON.stringify(before.args) === JSON.stringify(['-I', '-B', '-'])
    && before.memory === 512 * 1024 * 1024 && before.cpus === 1e9 && before.pids === 64 && before.caps.includes('ALL')
    && before.security.includes('no-new-privileges=true') && before.log.Type === 'none' && before.restart.Name === 'no'
    && Object.keys(before.ports ?? {}).length === 0 && (before.binds ?? []).length === 0, 'FIXED_TOPOLOGY');
  report.before = before;
  writeFileSync(STAGE + '/first-start.started', new Date().toISOString(), { flag: 'wx' });
  const command = await docker(['start', '--attach', '--interactive', cid], { timeout: 180000, input: script, allowFailure: true, stdoutLimit: 128 * 1024, stderrLimit: 8192 });
  save('first-start-command.json', command);
  report.client = { exitCode: command.exitCode, failure: command.failure, elapsedMs: command.elapsedMs };
  const after = await inspectContainer();
  ownedContainer(after);
  report.after = after;
  const output = JSON.parse(command.stdout);
  save('first-start-runtime.json', output);
  report.runtimeStatus = output.status;
  report.firstFailure = output.first_failure;
  report.shutdown = output.shutdown;
  assertFact(command.exitCode === 0 && !command.failure && after.state.Running === false && after.state.ExitCode === 0 && !after.state.OOMKilled, 'PAYLOAD_EXIT');
  assertFact(output.scope === report.scope && output.status === 'prerequisite_pass' && !output.first_failure
    && output.start_dispatches === 1 && output.sql?.system_identifier && output.shutdown?.state === 'checked'
    && output.shutdown.system_identifier === output.sql.system_identifier, 'PREREQUISITE_RESULT');
  report.executionPassed = true;
} catch (error) {
  report.error = String(error.message);
  process.exitCode = 1;
} finally {
  cleanupDeadline = performance.now() + 60000;
  try {
    assertFact((await docker(['info', '--format', '{{.ID}}'], cleanupOptions())).stdout.trim() === engine, 'CLEANUP_ENGINE');
    if (cid) {
      let current = await inspectContainer(cleanupOptions());
      ownedContainer(current);
      report.cleanupObserved = current;
      if (current.state.Running) {
        report.outerStopRequired = true;
        report.executionPassed = false;
        process.exitCode = 1;
        await docker(['stop', '--time', '45', cid], cleanupOptions(48000));
        current = await inspectContainer(cleanupOptions());
        ownedContainer(current);
      }
      assertFact(!current.state.Running, 'CONTAINER_STILL_RUNNING');
      await docker(['rm', cid], cleanupOptions());
      await absent('container', cid, cleanupOptions());
      report.containerRemoved = true;
    }
    if (volumeCreated) {
      report.volumeAtCleanup = await inspectVolume(cleanupOptions());
      const mounted = await docker(['ps', '--all', '--quiet', '--filter', 'volume=' + volume], cleanupOptions());
      assertFact(mounted.stdout.trim() === '', 'VOLUME_STILL_MOUNTED');
      await docker(['volume', 'rm', volume], cleanupOptions());
      await absent('volume', volume, cleanupOptions());
      report.volumeRemoved = true;
    }
    if (original) {
      const after = original.length ? (await docker(['container', 'inspect', '--format', originalFormat, ...original.map(x => x.id)], cleanupOptions())).stdout.trim().split(/\r?\n/).map(JSON.parse) : [];
      save('original-after-containers.json', after);
      assertFact(JSON.stringify(after) === JSON.stringify(original), 'ORIGINAL_WORKLOAD_DRIFT');
      const ids = (await docker(['ps', '--all', '--quiet', '--no-trunc'], cleanupOptions())).stdout.trim().split(/\r?\n/).filter(Boolean);
      assertFact(JSON.stringify(ids.sort()) === JSON.stringify(original.map(x => x.id).sort()), 'CONTAINER_ID_SET_CHANGED');
      report.originalContainersUnchanged = true;
    }
  } catch (error) {
    report.cleanupError = String(error.message);
    process.exitCode = 1;
  }
  report.finishedAt = new Date().toISOString();
  report.passed = report.executionPassed && report.containerRemoved === true && report.volumeRemoved === true && report.originalContainersUnchanged === true && !report.cleanupError;
  save('first-start-result.json', report);
  console.log(JSON.stringify({ passed: report.passed, runtimeStatus: report.runtimeStatus, firstFailure: report.firstFailure, shutdown: report.shutdown, error: report.error, cleanupError: report.cleanupError, containerRemoved: report.containerRemoved, volumeRemoved: report.volumeRemoved, originalContainersUnchanged: report.originalContainersUnchanged, evidence: STAGE + '/first-start-result.json' }));
  if (!report.passed) process.exitCode = 1;
}
