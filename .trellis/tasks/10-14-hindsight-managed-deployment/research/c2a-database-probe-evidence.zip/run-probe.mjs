import { readFileSync,writeFileSync,copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { STAGE,TOKEN,docker,assertFact } from './command-runner.mjs';
const research='H:/TakiAgent/.trellis/tasks/10-14-hindsight-managed-deployment/research';
const base='sha256:ba5161f9e70f2811c17a90e40921b17240ae275d51a7a4001fcb75fcb61c10db';
const name='taki-c2a-db-probe-'+TOKEN;
const report={version:1,scope:'non-starting-database-metadata-probe',token:TOKEN,name,base,startedAt:new Date().toISOString()};
const save=(name,value)=>writeFileSync(STAGE+'/'+name,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const pins={
  'docker-database/probe-runtime.py':'57d79748edba8100576eaf79f1090fecb6c2e227563d7522dadf22eead0afd13',
  'docker-database/README.md':'92ccfd530cac3bd4110b66502555daf056c157272a11b5c18c9316c0339831f2',
  'c2a-database-probe-review.md':'f21122c3b5c0d6bc7f3161093f361e4ad17105c76f3dc2547774884812ec06a0',
  'c2a-database-probe-review.json':'f0da444316da0f605e20ec522be0a94f54ab6c0fb338a6bed5ee91a420a8ce97'
};
for(const [path,expected] of Object.entries(pins)){
  assertFact(createHash('sha256').update(readFileSync(research+'/'+path)).digest('hex')===expected,'INPUT_PIN:'+path);
  copyFileSync(research+'/'+path,STAGE+'/'+path.replaceAll('/','-'));
}
report.inputHashes=pins;
const script=readFileSync(research+'/docker-database/probe-runtime.py');
writeFileSync(STAGE+'/probe.started',new Date().toISOString(),{flag:'wx'});
let cid;
let created=false;
const deadline=Date.now()+60000;
let cleanupDeadline;
const bounded=(max,cleanup=false)=>{
  const remaining=(cleanup?cleanupDeadline:deadline)-Date.now();
  assertFact(remaining>0,cleanup?'CLEANUP_DEADLINE':'PROBE_DEADLINE');
  return Math.min(max,remaining);
};
const format='{"id":{{json .Id}},"name":{{json .Name}},"image":{{json .Image}},"labels":{{json .Config.Labels}},"user":{{json .Config.User}},"entrypoint":{{json .Config.Entrypoint}},"args":{{json .Args}},"tty":{{json .Config.Tty}},"readOnly":{{json .HostConfig.ReadonlyRootfs}},"network":{{json .HostConfig.NetworkMode}},"mounts":{{json .Mounts}},"state":{{json .State}}}';
async function inspect(id,cleanup=false){
  const command=await docker(['container','inspect','--format',format,id],{timeout:bounded(10000,cleanup),allowFailure:cleanup,cleanup});
  if(command.exitCode!==0||command.failure)return null;
  return JSON.parse(command.stdout);
}
function owned(value){
  assertFact(value&&value.name==='/'+name&&value.image===base&&value.labels?.['taki.c2a.database-probe']===TOKEN
    &&value.labels?.['taki.c2a.role']==='database-metadata-probe'&&value.mounts.length===0,'OWNED_PROBE');
  if(cid)assertFact(value.id===cid,'ORIGINAL_CID');
}
try{
  const result=await docker(['create','--name',name,'--label','taki.c2a.database-probe='+TOKEN,'--label','taki.c2a.role=database-metadata-probe',
    '--pull','never','--network','none','--read-only','--user','1000:1000','--interactive','--log-driver','none',
    '--memory','256m','--cpus','1','--pids-limit','16','--cap-drop','ALL','--security-opt','no-new-privileges=true',
    '--entrypoint','/app/api/.venv/bin/python',base,'-I','-B','-'],{timeout:bounded(15000)});
  cid=result.stdout.trim();assertFact(/^[0-9a-f]{64}$/.test(cid),'CREATED_CID');created=true;report.containerId=cid;
  save('probe-container-id.json',{id:cid,name,token:TOKEN});
  const before=await inspect(cid);owned(before);
  assertFact(before.user==='1000:1000'&&before.readOnly===true&&before.network==='none'&&before.tty===false
    &&JSON.stringify(before.entrypoint)===JSON.stringify(['/app/api/.venv/bin/python'])
    &&JSON.stringify(before.args)===JSON.stringify(['-I','-B','-']),'PROBE_TOPOLOGY');
  report.before=before;
  const command=await docker(['start','--attach','--interactive',cid],{timeout:bounded(60000),input:script,allowFailure:true});
  save('probe-command.json',command);
  assertFact(command.exitCode===0&&!command.failure,'PROBE_COMMAND');
  assertFact(Buffer.byteLength(command.stdout)<=128*1024&&Buffer.byteLength(command.stderr)<=8192,'OUTPUT_BOUND');
  const output=JSON.parse(command.stdout);
  assertFact(output.scope==='cached-image-metadata-only'||output.evidence_complete===false,'PROBE_SCOPE');
  save('probe-runtime.json',output);
  const after=await inspect(cid);owned(after);report.after=after;
  assertFact(after.state.Running===false&&after.state.ExitCode===0&&!after.state.OOMKilled,'PROBE_EXIT');
  report.executionPassed=true;report.inventoryStatus=output.status;report.unresolved=output.unresolved;
}catch(error){
  report.executionPassed=false;report.error=String(error.message);process.exitCode=1;
}finally{
  cleanupDeadline=Date.now()+60000;
  try{
    let current=await inspect(cid??name,true);
    if(current){
      owned(current);cid??=current.id;report.containerId=cid;report.cleanupObserved=current;
      if(current.state.Running){
        await docker(['stop','--time','2',cid],{timeout:bounded(10000,true),cleanup:true});
        current=await inspect(cid,true);owned(current);assertFact(current.state.Running===false,'PROBE_STOP');
      }
      await docker(['rm',cid],{timeout:bounded(10000,true),cleanup:true});
    }else if(created){
      report.alreadyAbsent=true;
    }
    const absence=await docker(['container','ls','--all','--filter','name=^/'+name+'$','--format','{{.ID}}'],{timeout:bounded(10000,true),cleanup:true});
    assertFact(absence.stdout.trim()==='','PROBE_REMAINS');report.containerRemoved=true;
    const original=JSON.parse(readFileSync(STAGE+'/original-before-containers.json','utf8'));
    const ids=original.map(value=>value.id);
    const facts='{"id":{{json .Id}},"name":{{json .Name}},"status":{{json .State.Status}},"startedAt":{{json .State.StartedAt}},"restartPolicy":{{json .HostConfig.RestartPolicy.Name}}}';
    const currentOriginal=ids.length?(await docker(['container','inspect','--format',facts,...ids],{timeout:bounded(15000,true),cleanup:true})).stdout.trim().split(/\r?\n/).map(line=>JSON.parse(line)):[];
    assertFact(JSON.stringify(currentOriginal)===JSON.stringify(original),'ORIGINAL_WORKLOAD_DRIFT');
    report.originalContainersUnchanged=true;report.originalContainerCount=original.length;
  }catch(error){
    report.cleanupError=String(error.message);report.containerRemoved=false;process.exitCode=1;
  }
  report.finishedAt=new Date().toISOString();
  report.stagingRetainedForPreservation=STAGE;
  save('probe-result.json',report);
  console.log(JSON.stringify({executionPassed:report.executionPassed,inventoryStatus:report.inventoryStatus,unresolved:report.unresolved,
    containerRemoved:report.containerRemoved,originalContainersUnchanged:report.originalContainersUnchanged,evidence:STAGE+'/probe-result.json'}));
}
