// Authorized metadata-only preflight. No build, pull or container mutation commands exist here.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, statfsSync, writeFileSync } from 'node:fs';

const root = 'G:/TakiAgent-c2a-docker-acceptance/2026-10-14-r1';
const docker = 'C:/Program Files/Docker/Docker/resources/bin/docker.exe';
const endpoint = 'npipe:////./pipe/dockerDesktopLinuxEngine';
const before = JSON.parse(readFileSync(`${root}/before.json`, 'utf8'));
const launch = JSON.parse(readFileSync(`${root}/startup.json`, 'utf8'));
const started = Date.now();
const deadline = started + 300_000;
const initialG = before.capacity.find((drive) => drive.Name === 'G').Free;
const environment = { SystemRoot: process.env.SystemRoot, WINDIR: process.env.SystemRoot, TEMP: root, TMP: root };
const report = {
  version: 1, scope: 'authorized-startup-and-read-only-preflight', startedAt: new Date(started).toISOString(),
  endpoint, before, launch, commands: [], engine: null, containers: [], images: [], imageMetadata: [],
  startupMayActivateExistingRestartPolicies: true,
  activeContainerMutations: 0, builds: 0, pulls: 0, daemonInterruptions: 0,
  runtimeAcceptance: false, compatibleVenvAndNoDownloadBuilderVerified: false,
  driverSha256: createHash('sha256').update(readFileSync(`${root}/preflight.mjs`)).digest('hex'),
};

function capacity() {
  return ['C', 'G', 'H'].map((name) => {
    const value = statfsSync(`${name}:/`, { bigint: true });
    return { name, free: Number(value.bavail * value.bsize) };
  });
}

function guard() {
  if (Date.now() > deadline) throw new Error('Five-minute preflight deadline reached');
  const freeG = capacity().find((drive) => drive.name === 'G').free;
  if (freeG < 20 * 1024 ** 3 || initialG - freeG > 2 * 1024 ** 3) {
    throw new Error('Observed G: capacity threshold reached; existing workloads remain untouched');
  }
}

function query(name, args, retryStartup = false) {
  guard();
  const argv = ['--host', endpoint, '--config', `${root}/client-config`, ...args];
  const began = Date.now();
  const result = spawnSync(docker, argv, {
    env: environment, windowsHide: true, encoding: 'utf8', timeout: 10_000, maxBuffer: 1024 * 1024,
  });
  report.commands.push({ name, program: docker, argv, startedAt: new Date(began).toISOString(),
    milliseconds: Date.now() - began, exitCode: result.status, signal: result.signal,
    errorCode: result.error?.code ?? null,
    error: result.status === 0 ? null : (result.stderr ?? '').trim().slice(0, 500) });
  if (result.status !== 0) {
    if (retryStartup) return null;
    throw new Error(`Read-only query failed: ${name}`);
  }
  return result.stdout.trim();
}

function jsonLines(text) {
  return text ? text.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line)) : [];
}

try {
  const startupDeadline = Date.now() + 180_000;
  const engineFormat = '{"id":{{json .ID}},"os":{{json .OSType}},"architecture":{{json .Architecture}},"version":{{json .ServerVersion}},"liveRestore":{{json .LiveRestoreEnabled}}}';
  while (Date.now() < startupDeadline) {
    const output = query('engine-info', ['info', '--format', engineFormat], true);
    if (output) { report.engine = JSON.parse(output); break; }
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
  if (!report.engine) throw new Error('Engine did not become available within three minutes');
  if (report.engine.os !== 'linux' || !['x86_64', 'amd64'].includes(report.engine.architecture)) {
    throw new Error('Registered Linux/amd64 engine requirement is not met');
  }
  const ids = jsonLines(query('container-ids', ['container', 'ls', '--all', '--no-trunc', '--format', '{{json .ID}}']));
  const containerFormat = '{"id":{{json .Id}},"name":{{json .Name}},"status":{{json .State.Status}},"restartPolicy":{{json .HostConfig.RestartPolicy.Name}}}';
  for (const id of ids) {
    if (!/^[0-9a-f]{64}$/.test(id)) throw new Error('Unexpected container identity in inventory');
    report.containers.push(JSON.parse(query('container-state', ['container', 'inspect', '--format', containerFormat, id])));
  }
  const imageFormat = '{"id":{{json .ID}},"repository":{{json .Repository}},"tag":{{json .Tag}},"size":{{json .Size}}}';
  report.images = jsonLines(query('cached-native-images', ['image', 'ls', '--no-trunc', '--filter', 'reference=taki-hindsight-api:*', '--format', imageFormat]));
  const metadataFormat = '{"id":{{json .Id}},"os":{{json .Os}},"architecture":{{json .Architecture}},"user":{{json .Config.User}},"entrypoint":{{json .Config.Entrypoint}}}';
  for (const id of new Set(report.images.map((image) => image.id))) {
    if (!/^sha256:[0-9a-f]{64}$/.test(id)) throw new Error('Unexpected image identity in inventory');
    report.imageMetadata.push(JSON.parse(query('cached-native-metadata', ['image', 'inspect', '--format', metadataFormat, id])));
  }
  guard();
  report.status = 'complete';
  report.cachedNativeCandidatePresent = report.imageMetadata.length > 0;
} catch (error) {
  report.status = 'stopped';
  report.reason = error instanceof Error ? error.message : String(error);
  process.exitCode = 1;
} finally {
  report.completedAt = new Date().toISOString();
  report.milliseconds = Date.now() - started;
  report.capacityAfter = capacity();
  report.observedGUseIncrease = initialG - report.capacityAfter.find((drive) => drive.name === 'G').free;
  report.desktopDisposition = 'Left running; no daemon stop/restart authorized or issued';
  const output = JSON.stringify(report, null, 2) + '\n';
  if (Buffer.byteLength(output) > 64 * 1024 ** 2) throw new Error('Preflight evidence exceeds staging ceiling');
  writeFileSync(`${root}/preflight.json`, output);
  console.log(JSON.stringify({ status: report.status, reason: report.reason, engine: report.engine,
    containers: report.containers, cachedImages: report.imageMetadata, commands: report.commands.length,
    elapsedMs: report.milliseconds, observedGUseIncrease: report.observedGUseIncrease,
    evidence: `${root}/preflight.json` }, null, 2));
}
