"""INPUT: fixed private fake environment and safe startup identity from its owner.
OUTPUT: finite leaf-process lifetime and value-free PID/startup/exit markers.
POS: isolated C2a fake consumer child; imports no provider and opens no network.
"""

from __future__ import annotations

import json
import os
import re
import signal
import sys
import time
from pathlib import Path


def main() -> int:
    names = {
        "TAKI_C2A_FAKE_" + suffix
        for suffix in ("CONNECTION", "DEFAULT", "RETAIN", "REFLECT", "CONSOLIDATION", "EMBEDDING", "RERANKER")
    }
    values = [value for name, value in os.environ.items() if name in names]
    if (
        len(sys.argv) != 1
        or not values
        or any(not re.fullmatch(r"C2A_FAKE_[0-9a-f]{64}", value) for value in values)
        or os.environ.get("PYTHON_DOTENV_DISABLED") != "true"
        or any(name in os.environ for name in ("PYTHONPATH", "NODE_OPTIONS", "HINDSIGHT_API_LLM_API_KEY"))
    ):
        return 20
    # Exercise the same pinned dotenv library; disabled dotenv may not introduce
    # even a harmless fixture variable from the fresh data directory.
    from dotenv import load_dotenv

    before = dict(os.environ)
    load_dotenv(Path.cwd() / ".env", override=True)
    if dict(os.environ) != before:
        return 21
    startup_id = os.environ["TAKI_C2A_STARTUP_ID"]
    stopped = False

    def stop(_signum: int, _frame: object) -> None:
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, stop)
    marker = Path("c2a-child.json")
    staging = Path("c2a-child.staging")
    staging.write_text(json.dumps({"pid": os.getpid(), "startupId": startup_id, "state": "running"}), encoding="utf-8")
    staging.replace(marker)
    deadline = time.monotonic() + 300
    while not stopped and time.monotonic() < deadline:
        time.sleep(0.05)
    staging.write_text(json.dumps({"pid": os.getpid(), "startupId": startup_id, "state": "stopped"}), encoding="utf-8")
    staging.replace(marker)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
