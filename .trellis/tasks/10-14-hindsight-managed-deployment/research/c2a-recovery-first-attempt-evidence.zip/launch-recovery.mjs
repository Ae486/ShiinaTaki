import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { STAGE,run,assertFact } from './command-runner.mjs';
const launcher='H:/TakiAgent/.trellis/tasks/10-14-hindsight-managed-deployment/research/docker-recovery/run-recovery.ts';
assertFact(createHash('sha256').update(readFileSync(launcher)).digest('hex')==='f7c907eda8a156da8ca20be9d199c2d6ac5eb35ac84b01625ace6a50f608493e','LAUNCHER_PIN');
const result=await run('C:/Program Files/nodejs/node.exe',[launcher,'--execute-approved-recovery'],{
  timeout:14*60_000,allowFailure:true,
  env:{SystemRoot:process.env.SystemRoot,TEMP:STAGE,TMP:STAGE,WS_NO_BUFFER_UTIL:'1',WS_NO_UTF_8_VALIDATE:'1'}
});
writeFileSync(STAGE+'/launcher-command.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({exitCode:result.exitCode,failure:result.failure,elapsedMs:result.elapsedMs,stdout:result.stdout,stderr:result.stderr,evidence:STAGE+'/recovery.json'}));
process.exitCode=result.exitCode===0&&!result.failure?0:1;
