import hashlib,json,pathlib,shutil,sys
root=pathlib.Path(__file__).parent
manifest=root/'baseline.json'
rows=json.loads(manifest.read_text()) if manifest.exists() else []
seen={row['path'] for row in rows}
for arg in sys.argv[1:]:
    p=pathlib.Path(arg).resolve()
    name=p.as_posix()
    if name in seen: continue
    if not (name.startswith('H:/TakiAgent/') or name.startswith('H:/hindsight/')): raise ValueError('outside source roots')
    exists=p.exists()
    dest=root/'baseline'/name.replace(':','')
    row={'path':name,'existed':exists,'sha256':None,'baseline':None}
    if exists:
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dest)
        row.update(sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),baseline=dest.as_posix())
    rows.append(row)
manifest.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(len(rows),'baseline entries retained')
