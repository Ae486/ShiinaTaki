import os
import subprocess
import sys
environment={'SystemRoot':os.environ['SystemRoot'],'__PYVENV_LAUNCHER__':sys.executable}
child=subprocess.Popen([sys._base_executable,'-I','-B','-c','import os,sys,dotenv; print(os.getpid()); print(sys.prefix); print(dotenv.__file__)'], env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
out,err=child.communicate(timeout=10)
print('owned pid',child.pid,'exit',child.returncode)
print(out.decode(),err.decode())
