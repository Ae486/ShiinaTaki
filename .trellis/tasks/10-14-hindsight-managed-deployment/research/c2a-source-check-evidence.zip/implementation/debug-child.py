import os
import pathlib
import sys
import tempfile
import uuid

sys.path.insert(0, 'H:/hindsight/docker/standalone')
from managed_bootstrap.fake_consumer import C2FakeConsumer
from managed_bootstrap.protocol import ResolvedCredential, ResolvedCredentials, Slot

root=pathlib.Path(tempfile.mkdtemp(prefix='c2a-debug-',dir='G:/Temp/taki-c2a-source-20261014-impl'))
owner=C2FakeConsumer(str(uuid.uuid4()),root)
try:
    child=owner(ResolvedCredentials((ResolvedCredential(Slot.DEFAULT,'C2A_FAKE_'+'b'*64),)))
    print('started',child.process.pid)
    child.stop()
except Exception as error:
    print(type(error).__name__, str(error),root)
finally:
    for path in root.iterdir(): print(path.name,path.read_text(encoding='utf-8') if path.name=='c2a-child.json' else path.stat().st_size)
