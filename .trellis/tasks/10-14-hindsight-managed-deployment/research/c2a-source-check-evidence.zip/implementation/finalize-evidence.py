"""Capture the C2a implementer's preserved-baseline source and check evidence."""

import collections
import datetime
import difflib
import hashlib
import json
import pathlib
import subprocess
import sys

STAGING = pathlib.Path(__file__).parent
TASK = pathlib.Path("H:/TakiAgent/.trellis/tasks/10-14-hindsight-managed-deployment")
REPOSITORIES = {"TakiAgent": pathlib.Path("H:/TakiAgent"), "hindsight": pathlib.Path("H:/hindsight")}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def source_delta():
    baseline = load(STAGING / "baseline.json")
    files = []
    unchanged = []
    excluded = []
    errors = []
    for entry in baseline:
        path = pathlib.Path(entry["path"])
        repository, root = next((name, root) for name, root in REPOSITORIES.items() if path.is_relative_to(root))
        relative = path.relative_to(root).as_posix()
        if relative.startswith(".trellis/"):
            excluded.append(entry["path"])
            continue
        after = digest(path) if path.exists() else None
        if after == entry["sha256"]:
            unchanged.append(entry["path"])
            continue
        before_bytes = pathlib.Path(entry["baseline"]).read_bytes() if entry["baseline"] else b""
        after_bytes = path.read_bytes() if path.exists() else b""
        if hashlib.sha256(before_bytes).hexdigest() != entry["sha256"] and entry["existed"]:
            errors.append(f"baseline hash mismatch: {entry['path']}")
        if after_bytes.startswith(b"\xef\xbb\xbf"):
            errors.append(f"UTF-8 BOM: {entry['path']}")
        before_lines = before_bytes.decode("utf-8").splitlines()
        after_lines = after_bytes.decode("utf-8").splitlines()
        for tag, _, _, start, end in difflib.SequenceMatcher(None, before_lines, after_lines, autojunk=False).get_opcodes():
            if tag in ("insert", "replace"):
                for number in range(start, end):
                    if after_lines[number].endswith((" ", "\t")):
                        errors.append(f"introduced trailing whitespace: {entry['path']}:{number + 1}")
        files.append({
            "repository": repository, "path": relative, "absolutePath": path.as_posix(),
            "change": "deleted" if not path.exists() else "modified" if entry["existed"] else "added",
            "beforeSha256": entry["sha256"], "afterSha256": after, "bytes": len(after_bytes),
            "baselineCopy": entry["baseline"],
        })
    if errors:
        raise RuntimeError("\n".join(errors))
    files.sort(key=lambda row: (row["repository"], row["path"]))
    return baseline, files, unchanged, excluded


def command(root, *arguments):
    return subprocess.check_output(["git", "-C", str(root), *arguments], text=True, encoding="utf-8").strip()


def main():
    baseline, files, unchanged, excluded = source_delta()
    if "--check-source-text" in sys.argv:
        print(f"PASS: {len(files)} changed source files decode as UTF-8 without BOM or introduced trailing whitespace; preserved baseline hashes match.")
        return
    checks = []
    for line in (STAGING / "checks.jsonl").read_text(encoding="utf-8-sig").splitlines():
        row = json.loads(line)
        log = pathlib.Path(row["log"])
        row["logSha256"] = digest(log) if log.exists() else None
        row["logFileState"] = "retained" if log.exists() else "legacy-wrapper-created-no-file-for-silent-command"
        checks.append(row)
    installed = max(STAGING.glob("taki-c2a-fixture-*.json"), key=lambda path: path.stat().st_mtime)
    proof = load(installed)
    resources = STAGING / "owned-resources-final.json"
    replay_inputs = [
        STAGING / "baseline.py", STAGING / "run-check.ps1", STAGING / "changed-ts.json",
        STAGING / "changed-py.json", STAGING / "fake-key-adapter.exe", pathlib.Path(__file__),
        REPOSITORIES["TakiAgent"] / "apps/hindsight-host/test-fixtures/fake-key-adapter.rs",
    ]
    manifest = {
        "version": 1,
        "recordedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "task": str(TASK.as_posix()),
        "verdict": "implementer-self-check-complete-independent-source-review-pending",
        "deploymentReady": False,
        "comparison": "Per-file baseline captured before C2a edits; includes pre-existing dirty source. This is not a diff against Git HEAD.",
        "baseline": {"path": str((STAGING / "baseline.json").as_posix()), "sha256": digest(STAGING / "baseline.json"),
                     "entries": len(baseline), "sourceEntries": len(files) + len(unchanged),
                     "excludedTaskArtifacts": excluded, "unchangedSourceEntries": unchanged},
        "repositories": [{"name": name, "root": root.as_posix(), "branch": command(root, "branch", "--show-current"),
                          "head": command(root, "rev-parse", "HEAD")} for name, root in REPOSITORIES.items()],
        "changedFileCount": len(files),
        "changedFilesByRepository": dict(collections.Counter(row["repository"] for row in files)),
        "changes": dict(collections.Counter(row["change"] for row in files)),
        "sourceTextCheck": "UTF-8 without BOM; no introduced trailing whitespace; preserved baseline copy hashes match",
        "sourceTreeSha256": hashlib.sha256(json.dumps(files, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "files": files,
        "checksJsonl": {"path": (STAGING / "checks.jsonl").as_posix(), "sha256": digest(STAGING / "checks.jsonl"), "records": len(checks)},
        "checks": checks,
        "installedFixture": {"path": installed.as_posix(), "sha256": digest(installed),
                             "engine": proof["engine"], "result": proof["result"], "counts": proof["counts"],
                             "pids": proof["pids"], "ownedCleanup": proof["ownedCleanup"],
                             "manifestSha256": proof["manifestSha256"], "runtimeSha256": proof["runtimeSha256"],
                             "nodeSha256": proof["nodeSha256"], "fakeDockerSha256": proof["fakeDockerSha256"]},
        "cleanup": {"path": resources.as_posix(), "sha256": digest(resources), "inventory": load(resources)},
        "retainedReplayInputs": [{"path": path.as_posix(), "sha256": digest(path)} for path in replay_inputs],
        "limits": ["substituted engine; no actual Docker or database", "Windows process proof; no new Linux control-socket execution",
                   "no real Catalog/keyring/data/models", "no C2b trusted deployment receipt", "no C3 provider/model acceptance",
                   "baseline and replay resources retained for independent acceptance"],
    }
    target = TASK / "research/c2a-implementation-source-manifest.json"
    target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"manifest": target.as_posix(), "sha256": digest(target),
                      "changedFileCount": manifest["changedFileCount"], "repositories": manifest["changedFilesByRepository"],
                      "changes": manifest["changes"], "sourceTreeSha256": manifest["sourceTreeSha256"],
                      "checkRecords": len(checks), "silentLogEntries": [row["name"] for row in checks if row["logSha256"] is None],
                      "installed": manifest["installedFixture"]}, indent=2))


if __name__ == "__main__":
    main()
