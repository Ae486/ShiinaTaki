import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('H:/TakiAgent')
dest = root / 'packages/shared/fixtures/protocol'
base = json.loads((dest / 'hindsight-custody-invocation.windows.valid.json').read_text())
one = '11111111-1111-4111-8111-111111111111'
two = '22222222-2222-4222-8222-222222222222'
three = '33333333-3333-4333-8333-333333333333'
plan = dict(version=1, deploymentId=one, operationId=one, coreHostId=one, executionHostId=two,
    installationId='b'*64, deploymentRegistrationSha256='d'*64, engineId='C2A-FIXTURE', imageId='sha256:'+'e'*64,
    configurationDigest='c'*64, consumer='c2a-fake-v1', storage='new-named-volume')
custody = dict(input=base['input'], mapping=dict(coreOperationId=one, coreAttemptId=three, brokerOperationId=one,
    hostAttemptId=two, requestId=one, inputDigest='b'*64), deadlineAt=base['control']['deadlineAt'])
effect = dict(version=1, action='inject', plan=plan, custody=custody, containerId='a'*64, startupId=three)
control = copy.deepcopy(base['control'])
control.update(capabilityId='hindsight-deployment', coreAttemptId=three, effectId=three)
control['governanceProjection'].update(registryRevision=3, cells=[dict(key='hindsight-deployment:'+action, posture='auto') for action in ['create','inject','start']])
invocation = dict(version=1, requestId=one, control=control, owner=base['owner'], input=effect)
checkpoint = dict(version=1, requestId=one, control=control, checkpointId=three, deploymentId=one,
    containerId='a'*64, startupId=three, configurationDigest='c'*64, custodySnapshotId=one)
permit = dict(version=1, checkpointId=three, binding=dict(startupId=three, configurationDigest='c'*64,
    operationId=one, attemptId=two, authorizationId=three, deadlineAt=control['deadlineAt']),
    selection=[dict(slot=entry['slot'], source=entry['source']) for entry in base['input']['selection']])
status = dict(version=1, state='running', deploymentId=one, operationId=one, configurationDigest='c'*64,
    containerId='a'*64, startupId=three, attemptId=two, deploymentReady=False)
registration = dict(version=1, installationId='b'*64, coreHostId=one, executionHostId=two,
    docker=dict(path='C:\\Program Files\\Docker\\docker.exe', sha256='a'*64, version='fixture-1',
        endpoint='npipe:////./pipe/dockerDesktopLinuxEngine', engineId='C2A-FIXTURE'),
    image=dict(id='sha256:'+'e'*64, os='linux', architecture='amd64', consumer='c2a-fake-v1', bootstrapVersion=1),
    stateDirectory='C:\\ProgramData\\Taki\\fixture-state')
fixtures = {}
def add(prefix, label, value, valid=True):
    fixtures[f'hindsight-deployment-{prefix}.{label}.{"valid" if valid else "invalid"}.json'] = value
def change(prefix, value, field, replacement):
    changed = copy.deepcopy(value)
    target = changed
    parts = field.split('/')
    for part in parts[:-1]: target = target[part]
    target[parts[-1]] = replacement
    add(prefix, field.replace('/','-'), changed, False)
add('effect','inject', effect)
add('effect','create', dict(version=1, action='create', plan=plan, custody=custody))
add('effect','start', dict(version=1, action='start', plan=plan, custody=custody, containerId='a'*64))
add('invocation','windows', invocation)
add('observe','original', dict(version=1, deploymentId=one))
add('checkpoint','current', checkpoint)
add('checkpoint-result','granted', dict(state='granted', permit=permit))
add('checkpoint-result','refused', dict(state='unavailable', reason='registry-unavailable'))
add('status','running', status)
add('status','missing', dict(version=1, state='unavailable', reason='registry-unavailable', deploymentReady=False))
add('registration','windows', registration)
change('effect', effect, 'plan/operationId', three)
change('effect', effect, 'custody/input/configurationDigest', 'f'*64)
change('effect', effect, 'containerId', None)
change('effect', effect, 'command', 'forbidden')
change('invocation', invocation, 'authorization', None)
change('invocation', invocation, 'control/effectId', None)
change('invocation', invocation, 'input/startupId', None)
change('checkpoint', checkpoint, 'authorization', None)
change('checkpoint-result', dict(state='granted',permit=permit), 'permit/selection', [dict(slot='connectionApiKey',source='inherit-default')])
change('checkpoint-result', dict(state='granted',permit=permit), 'permit/selection', [dict(slot='defaultModelApiKey',source='catalog')]*2)
change('status', status, 'deploymentReady', True)
change('status', status, 'reason', None)
change('status', status, 'attemptId', None)
change('registration', registration, 'docker/endpoint', 'tcp://localhost:2375')
subprocess.run([sys.executable, str(Path(__file__).with_name('baseline.py')), *[str(dest/name) for name in fixtures]], check=True)
for name, value in fixtures.items(): (dest/name).write_text(json.dumps(value,indent=2)+'\n', encoding='utf-8')
canonical = json.dumps(dict(capabilityId='hindsight-deployment-plan:v1', input=plan),sort_keys=True,separators=(',',':'))
print('plan sha256',hashlib.sha256(canonical.encode()).hexdigest())
