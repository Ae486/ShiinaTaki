param([string]$Name,[string]$Program,[string[]]$Arguments)
$env:PATH = 'C:/Program Files/nodejs;' + $env:PATH
$checkRoot = 'G:/Temp/taki-c2a-source-20261014-impl'
$start = [DateTime]::UtcNow
$checkOutput = & $Program @Arguments 2>&1
$code = $LASTEXITCODE
$log = Join-Path $checkRoot ($Name + '.log')
$checkOutput | Set-Content -LiteralPath $log -Encoding utf8
@{ name=$Name; cwd=(Get-Location).Path; program=$Program; arguments=$Arguments; started=$start.ToString('o'); seconds=([DateTime]::UtcNow-$start).TotalSeconds; exitCode=$code; log=$log } | ConvertTo-Json -Compress | Add-Content -LiteralPath (Join-Path $checkRoot 'checks.jsonl') -Encoding utf8
$checkOutput
exit $code
