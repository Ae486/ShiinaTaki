"""Independently verify the released C2a source, baseline and retained evidence."""

import difflib
import hashlib
import json
from pathlib import Path

TASK = Path("H:/TakiAgent/.trellis/tasks/10-14-hindsight-managed-deployment")
REVIEW = Path(__file__).parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


manifest_path = TASK / "research/c2a-implementation-source-manifest.json"
assert sha(manifest_path) == "f27379be3b4b5e61e1b2821c2eda2d87bf54e5c2983b034bdb637ee789961ae2"
manifest = load(manifest_path)
assert sha(TASK / "research/c2a-implementation-self-check.md") == "b0480b3792c6a4aac32de7e6bfde2b5a48d9a51bbb2740a1cf7255500b1d4dc4"
assert sha(manifest["baseline"]["path"]) == manifest["baseline"]["sha256"]
baseline = load(manifest["baseline"]["path"])
assert len(baseline) == 113
baseline_by_path = {entry["path"]: entry for entry in baseline}
for entry in baseline:
    if entry["existed"]:
        assert sha(entry["baseline"]) == entry["sha256"], entry["path"]

assert len(manifest["files"]) == 109
for entry in manifest["files"]:
    path = Path(entry["absolutePath"])
    assert sha(path) == entry["afterSha256"], entry["absolutePath"]
    original = baseline_by_path[path.as_posix()]
    assert original["sha256"] == entry["beforeSha256"]
    assert original["baseline"] == entry["baselineCopy"]
    after_bytes = path.read_bytes()
    assert len(after_bytes) == entry["bytes"]
    assert not after_bytes.startswith(b"\xef\xbb\xbf"), path
    after_lines = after_bytes.decode("utf-8").splitlines()
    before_lines = Path(original["baseline"]).read_text(encoding="utf-8").splitlines() if original["existed"] else []
    for tag, _, _, start, end in difflib.SequenceMatcher(None, before_lines, after_lines, autojunk=False).get_opcodes():
        if tag in ("insert", "replace"):
            for number in range(start, end):
                assert not after_lines[number].endswith((" ", "\t")), (str(path), number + 1)

for name in manifest["baseline"]["unchangedSourceEntries"]:
    entry = baseline_by_path[name]
    assert (sha(name) if Path(name).exists() else None) == entry["sha256"]

tree_sha = hashlib.sha256(json.dumps(manifest["files"], ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
assert tree_sha == "b0e7896be6c5e49c7d588fb59a537787c1614c6bc302cacda30372c001eca2f9"
assert tree_sha == manifest["sourceTreeSha256"]

prefix = (REVIEW / "implementation-checks-prefix.jsonl").read_bytes()
assert hashlib.sha256(prefix).hexdigest() == manifest["checksJsonl"]["sha256"]
assert Path(manifest["checksJsonl"]["path"]).read_bytes().startswith(prefix)
original_checks = [json.loads(line) for line in prefix.decode("utf-8-sig").splitlines()]
assert len(original_checks) == len(manifest["checks"]) == 54
silent = []
for check, original in zip(manifest["checks"], original_checks, strict=True):
    assert all(check[key] == value for key, value in original.items()), check["name"]
    if check["logSha256"]:
        assert sha(check["log"]) == check["logSha256"], check["name"]
    else:
        assert check["logFileState"] == "legacy-wrapper-created-no-file-for-silent-command"
        assert not Path(check["log"]).exists()
        silent.append(check["name"])

for entry in manifest["retainedReplayInputs"]:
    assert sha(entry["path"]) == entry["sha256"], entry["path"]
for key in ("installedFixture", "cleanup"):
    assert sha(manifest[key]["path"]) == manifest[key]["sha256"]

print(json.dumps({
    "status": "pass",
    "sourceFiles": len(manifest["files"]),
    "sourceTreeSha256": tree_sha,
    "baselineEntries": len(baseline),
    "preservedCheckRecords": len(original_checks),
    "retainedLogsVerified": len(original_checks) - len(silent),
    "disclosedOriginalSilentLogs": silent,
    "sourceText": "UTF-8 without BOM and no introduced trailing whitespace",
    "reviewSourceDelta": [],
}, indent=2))
