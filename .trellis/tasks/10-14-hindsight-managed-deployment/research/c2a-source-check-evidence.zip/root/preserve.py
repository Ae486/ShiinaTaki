"""Preserve this task's exact source delta and small check evidence; never roll back a checkout."""

import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).parent
TASK = pathlib.Path('H:/TakiAgent/.trellis/tasks/10-14-hindsight-managed-deployment/research')
IMPL = pathlib.Path('G:/Temp/taki-c2a-source-20261014-impl')
CHECK = pathlib.Path('G:/Temp/taki-c2a-independent-20261014-check')
REPOS = {'TakiAgent': pathlib.Path('H:/TakiAgent'), 'hindsight': pathlib.Path('H:/hindsight')}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest_path = TASK / 'c2a-implementation-source-manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
independent_path = TASK / 'c2a-independent-source-evidence.json'
if not independent_path.is_file():
    raise RuntimeError('Independent evidence must be released before preservation.')
baseline_path = IMPL / 'baseline.json'
if sha(baseline_path) != '1bac2d220ad7d4a31e090e55159452875efddc042db097b543aa0222f0e66a04':
    raise RuntimeError('Original baseline changed; reconcile it before preserving.')
files = manifest['files']
for row in files:
    current = pathlib.Path(row['absolutePath'])
    if sha(current) != row['afterSha256']:
        raise RuntimeError(f'Final source differs from released implementation: {current}')
    if row['beforeSha256'] and sha(pathlib.Path(row['baselineCopy'])) != row['beforeSha256']:
        raise RuntimeError(f'Baseline bytes differ: {current}')

patches = []
for repository, repo in REPOS.items():
    stage = ROOT / repository
    before = stage / 'before'
    after = stage / 'after'
    before.mkdir(parents=True, exist_ok=False)
    after.mkdir()
    selected = [row for row in files if row['repository'] == repository]
    for row in selected:
        target = after / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(row['absolutePath'], target)
        if row['baselineCopy']:
            target = before / row['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(row['baselineCopy'], target)
    command = ['git', '-c', 'core.autocrlf=false', 'diff', '--no-index', '--binary',
               '--no-ext-diff', '--no-textconv', '--no-renames', '--', 'before', 'after']
    result = subprocess.run(command, cwd=stage, capture_output=True, check=False)
    if result.returncode != 1:
        raise RuntimeError(f'Expected source delta for {repository}: {result.stderr.decode()}')
    patch = result.stdout
    for prefix in (b'a/', b'b/'):
        for directory in (b'before/', b'after/'):
            patch = patch.replace(prefix + directory, prefix)
    patch_path = TASK / f'c2a-source-delta-{repository.lower()}.patch'
    with patch_path.open('xb') as stream:
        stream.write(patch)
    verify = ['git', '-c', 'core.autocrlf=false', 'apply', '--reverse', '--check', str(patch_path)]
    check = subprocess.run(verify, cwd=repo, capture_output=True, check=False)
    if check.returncode:
        raise RuntimeError(f'Read-only reverse check failed: {check.stderr.decode()}')
    patches.append({'repository': repository, 'path': patch_path.name, 'files': len(selected),
                    'bytes': len(patch), 'sha256': sha(patch_path), 'reverseCheck': {'argv': verify, 'exitCode': 0}})

archive_path = TASK / 'c2a-source-check-evidence.zip'
entries = []
sources = []
for label, folder in [('implementation', IMPL), ('independent', CHECK), ('root', ROOT)]:
    # Only the inspected small top-level evidence, never baselines, build caches or binaries.
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix.lower() in {'.json', '.jsonl', '.log', '.md', '.py', '.ps1', '.txt'}:
            sources.append((f'{label}/{path.name}', path))
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in sources:
        archive.write(path, name)
        entries.append({'path': name, 'sourcePath': path.as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)})
with zipfile.ZipFile(archive_path) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('Evidence archive CRC mismatch.')
    for row in entries:
        if hashlib.sha256(archive.read(row['path'])).hexdigest() != row['sha256']:
            raise RuntimeError(f'Archived evidence mismatch: {row["path"]}')

records = []
for name in ['c2a-implementation-self-check.md', 'c2a-implementation-source-manifest.json',
             'c2a-source-review.md', 'c2a-independent-source-evidence.json']:
    path = TASK / name
    records.append({'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)})
record = {
    'version': 1,
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'task': '10-14-hindsight-managed-deployment',
    'sourceFilesVerified': len(files),
    'sourceTreeSha256': manifest['sourceTreeSha256'],
    'sourceMismatchCount': 0,
    'baseline': {'sha256': sha(baseline_path), 'archivedAs': 'implementation/baseline.json',
                 'disposition': 'Exact task-only reverse-checkable patches replace temporary before-file copies.'},
    'reports': records,
    'patches': patches,
    'evidenceArchive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size,
                        'sha256': sha(archive_path), 'entries': entries},
    'cleanup': {'state': 'pending-owned-temporary-tree-cleanup'},
    'limits': ['No source rollback or Git lifecycle action was executed.',
               'Metadata/spec/handoff edits are outside the preserved 109-file implementation delta.',
               'Real Docker, Linux C2 runtime, database, original-data and model acceptance remain open.'],
}
record_path = TASK / 'c2a-root-final-readback.json'
record_path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'sourceFiles': len(files), 'patches': patches,
                  'archiveBytes': archive_path.stat().st_size, 'archiveEntries': len(entries),
                  'record': str(record_path)}, indent=2))
